package org.example;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException {
        LibroService methods = new LibroService();
        Libro libro2 = new Libro("Libro1JDBC1", 23, 8);
        Libro libro3 = new Libro("Libro2JDBC2", 30, 5);
        List<Libro> listaLibros = new ArrayList<Libro>();
        listaLibros.add(libro2);
        listaLibros.add(libro3);
        methods.insertar(listaLibros);
        System.out.println( methods.listar());
        libro2.setNombre("El libro de Hugo");
        methods.modificar(libro2);
        System.out.println( methods.listar());
    }
}

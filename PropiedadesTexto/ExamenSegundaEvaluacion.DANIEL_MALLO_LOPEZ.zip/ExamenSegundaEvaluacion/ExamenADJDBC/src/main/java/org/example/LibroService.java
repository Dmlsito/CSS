package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class LibroService {

    public LibroService(){}

    public void modificar(Libro libro) throws SQLException {
        Connection connection = null;
        PreparedStatement p = null;
        try{
            connection = HikariCP.getConnection();
            p = connection.prepareStatement("UPDATE Libros SET Nombre = ? WHERE Precio = ?");
            p.setString(1, libro.getNombre());
            p.setFloat(2, libro.getPrecio());
            p.executeUpdate();
        }catch(SQLException e){
            System.out.println("Ha ocurrido un error");
            throw new RuntimeException(e);
        }finally {
            if(connection != null) connection.close();
            if(p != null) p.close();
        }
    }

    public void insertar(List<Libro> listaLibros) throws SQLException {

        Connection connection = null;
        PreparedStatement p = null;

        try {
            connection = HikariCP.getConnection();
            connection.setAutoCommit(false);
            p = connection.prepareStatement("INSERT INTO Libros (Nombre, Precio, Puntuacion_Usuario) VALUES (?, ?, ?)");
            for(Libro libro: listaLibros) {
                p.setString(1, libro.getNombre());
                p.setFloat(2, libro.getPrecio());
                p.setInt(3, libro.getPuntuacionUsuario());
                p.executeUpdate();
            }
            connection.commit();

        } catch (SQLException e) {
            System.out.println("Ha ocurrido un error en la insercion");
            connection.rollback();

        }finally{
            if (connection != null) connection.close();
            if (p != null) p.close();}
    }

    public List<Libro> listar() throws SQLException{
        Connection connection = null;
        PreparedStatement p = null;
        List<Libro> listaLibros = new LinkedList<Libro>();

        try{
            connection = HikariCP.getConnection();
            p = connection.prepareStatement("SELECT * FROM Libros");
            ResultSet info = p.executeQuery();
            while(info.next()){
                Libro libro = new Libro();
                libro.setNombre(info.getString("Nombre"));
                libro.setPrecio(info.getFloat("Precio"));
                libro.setPuntuacionUsuario(info.getInt("Puntuacion_Usuario"));
                listaLibros.add(libro);
            }
            return listaLibros;
        }catch(SQLException e){
            throw new RuntimeException(e);

        }finally{
            if(connection != null) connection.close();
            if(p != null) p.close();
        }
    }






}

package org.example;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Libro libro = new Libro( "Libro1", 34, 10);
        LibroService methods = new LibroService();
        int idLibroInsertado =  methods.insertar(libro);
        System.out.println(methods.consultar(idLibroInsertado));
        libro.setNombre("NombreDePrueba");
        methods.actualizar(libro);
        System.out.println(methods.listarTodo());
    }
}

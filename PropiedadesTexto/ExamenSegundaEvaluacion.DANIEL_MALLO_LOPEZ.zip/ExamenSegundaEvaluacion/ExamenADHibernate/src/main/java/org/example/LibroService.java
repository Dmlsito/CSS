package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class LibroService {

    public LibroService(){}


    //Metodo insertar libro
    public int insertar(Libro libro){
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        session.save(libro);
        transaction.commit();
        return libro.getId();
    }

    //Metodo actualizar libro
    public void actualizar(Libro libro){
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session sesion =  sessionFactory.getCurrentSession();
        Transaction transaction = sesion.beginTransaction();
        sesion.update(libro);
        transaction.commit();

    }
    //Metodo para consultar Libro
    public Libro consultar(int id){
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        Libro libro = session.get(Libro.class, id);
        transaction.commit();
        return libro;
    }

    //Metodo listar todos los libros
    public List<Libro> listarTodo(){
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        Query<Libro> query = session.createNativeQuery("SELECT * FROM Libros", Libro.class);
        List<Libro> listLibros= query.list();
        transaction.commit();
        return listLibros;
    }


}

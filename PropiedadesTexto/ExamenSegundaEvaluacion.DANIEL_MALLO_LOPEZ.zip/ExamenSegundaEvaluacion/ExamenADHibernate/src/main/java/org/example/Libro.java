package org.example;


import javax.persistence.*;
import java.awt.image.SampleModel;

@Entity
@Table(name = "Libros")
public class Libro {
    private int id;
    private String nombre;
    private float precio;
    private int puntuacionUsuario;

    public Libro() {
    }
    public Libro(String nombre, float precio, int puntuacionUsuario) {

        this.nombre = nombre;
        this.precio = precio;
        this.puntuacionUsuario = puntuacionUsuario;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    @Column(name = "Nombre")
    public String getNombre() {
        return nombre;
    }
    @Column(name = "Precio")
    public float getPrecio() {
        return precio;
    }
    @Column(name = "Puntuacion_Usuario")
    public int getPuntuacionUsuario() {
        return puntuacionUsuario;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public void setPuntuacionUsuario(int puntuacionUsuario) {
        this.puntuacionUsuario = puntuacionUsuario;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", puntuacionUsuario=" + puntuacionUsuario +
                '}';
    }
}
